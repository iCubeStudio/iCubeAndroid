/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.rxw.panconnection.service.wifi;

import android.annotation.NonNull;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.TetheringManager;
import android.net.wifi.SoftApConfiguration;
import android.net.wifi.SoftApInfo;
import android.net.wifi.WifiClient;
import android.net.wifi.WifiManager;
import android.util.Log;

import com.android.internal.util.ConcurrentUtils;

import java.util.List;


public class WifiTetheringHandler {

    private final static String TAG = "WifiTetheringHandler";

    private final Context mContext;
    private final WifiManager mWifiManager;
    private final TetheringManager mTetheringManager;
    private final WifiTetheringAvailabilityListener mWifiTetheringAvailabilityListener;
    private boolean mRestartBooked = false;

    private final WifiManager.SoftApCallback mSoftApCallback = new WifiManager.SoftApCallback() {
        @Override
        public void onStateChanged(int state, int failureReason) {
            handleWifiApStateChanged(state);
        }

        @Override
        public void onConnectedClientsChanged(@NonNull SoftApInfo info,
                @NonNull List<WifiClient> clients) {
            mWifiTetheringAvailabilityListener.onConnectedClientsChanged(clients.size());
        }
    };

    public WifiTetheringHandler(Context context,
                                WifiTetheringAvailabilityListener wifiTetherAvailabilityListener) {
        this(context,context.getSystemService(WifiManager.class),
                context.getSystemService(TetheringManager.class), wifiTetherAvailabilityListener);
    }

    private WifiTetheringHandler(Context context, WifiManager wifiManager,
                                TetheringManager tetheringManager, WifiTetheringAvailabilityListener
            wifiTetherAvailabilityListener) {
        mContext = context;
        mWifiManager = wifiManager;
        mTetheringManager = tetheringManager;
        mWifiTetheringAvailabilityListener = wifiTetherAvailabilityListener;
    }

    public void configureAndStartHotspot() {
        SoftApConfiguration.Builder builder = new SoftApConfiguration.Builder();
        builder.setSsid("PanConnectionSSID")
                .setPassphrase("12345678", SoftApConfiguration.SECURITY_TYPE_WPA2_PSK)
                .setBand(SoftApConfiguration.BAND_2GHZ)
                .setHiddenSsid(false);

        SoftApConfiguration config = builder.build();
        mWifiManager.setSoftApConfiguration(config);
        updateWifiTetheringState(true);
    }

    /**
     * Handles operations that should happen in host's onStartInternal().
     */
    private void onStartInternal() {
        mWifiManager.registerSoftApCallback(mContext.getMainExecutor(), mSoftApCallback);
    }

    /**
     * Handles operations that should happen in host's onStopInternal().
     */
    private void onStopInternal() {
        mWifiManager.unregisterSoftApCallback(mSoftApCallback);
    }

    /**
     * Returns whether wifi tethering is enabled
     * @return whether wifi tethering is enabled
     */
    public boolean isWifiTetheringEnabled() {
        return mWifiManager.isWifiApEnabled();
    }

    /**
     * Changes the Wifi tethering state
     *
     * @param enable Whether to attempt to turn Wifi tethering on or off
     */
    public void updateWifiTetheringState(boolean enable) {
        if (enable) {
            startTethering();
        } else {
            stopTethering();
        }
    }

    private void handleWifiApStateChanged(int state) {
        Log.d(TAG, "handleWifiApStateChanged, state: " + state);
        switch (state) {
            case WifiManager.WIFI_AP_STATE_ENABLING:
                break;
            case WifiManager.WIFI_AP_STATE_ENABLED:
                mWifiTetheringAvailabilityListener.onWifiTetheringAvailable();
                break;
            case WifiManager.WIFI_AP_STATE_DISABLING:
                mWifiTetheringAvailabilityListener.onWifiTetheringUnavailable();
                break;
            case WifiManager.WIFI_AP_STATE_DISABLED:
                mWifiTetheringAvailabilityListener.onWifiTetheringUnavailable();
                if (mRestartBooked) {
                    // Hotspot was disabled as part of a restart request - we can now re-enable it
                    startTethering();
                    mRestartBooked = false;
                }
                break;
            default:
                mWifiTetheringAvailabilityListener.onWifiTetheringUnavailable();
                break;
        }
    }

    private void startTethering() {
        mTetheringManager.startTethering(ConnectivityManager.TETHERING_WIFI,
                ConcurrentUtils.DIRECT_EXECUTOR, new TetheringManager.StartTetheringCallback() {
                    @Override
                    public void onTetheringFailed(int error) {
                        Log.d(TAG, "onTetheringFailed, error: " + error);
                        mWifiTetheringAvailabilityListener.onWifiTetheringUnavailable();
                    }

                    @Override
                    public void onTetheringStarted() {
                        Log.d(TAG, "onTetheringStarted!");
                    }
                });
    }

    private void stopTethering() {
        mTetheringManager.stopTethering(ConnectivityManager.TETHERING_WIFI);
    }

    private void restartTethering() {
        stopTethering();
        mRestartBooked = true;
    }

    /**
     * Interface for receiving Wifi tethering status updates
     */
    public interface WifiTetheringAvailabilityListener {
        /**
         * Callback for when Wifi tethering is available
         */
        void onWifiTetheringAvailable();

        /**
         * Callback for when Wifi tethering is unavailable
         */
        void onWifiTetheringUnavailable();

        /**
         * Callback for when the number of tethered devices has changed
         * @param clientCount number of connected clients
         */
        default void onConnectedClientsChanged(int clientCount){
        }

    }
}
